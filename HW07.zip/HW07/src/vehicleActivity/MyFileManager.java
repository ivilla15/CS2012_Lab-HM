package vehicleActivity;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import java.text.SimpleDateFormat;  
import java.util.Date;    

public class MyFileManager {

	public static void main(String[] args) {
		File myObj = new File("VehicleProductionInventory.txt");
		clearFile("VehicleProductionInventory.txt");
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");  
	    Date date = new Date(); 
	    appendLine("Number of Vehicles Produced ","VehicleProductionInventory.txt");  
	    appendLine("Date of production "+formatter.format(date),"VehicleProductionInventory.txt");  
	    Vehicle []vehicles=VehicleFactoryMain.getNumArray();
	    ArrayList<Vehicle> list = new ArrayList<Vehicle>(Arrays.asList(vehicles));
	    appendArray(list, "VehicleProductionInventory.txt");
	}
	public static void clearFile(String fileName) {
		File myObj = new File(fileName);
		try {
			Scanner newinput= new Scanner(myObj);
			if(myObj.exists()) {
				myObj.delete();
			}
			newinput.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public static void appendLine(String lineToPrint, String fileName) {
		PrintWriter prtout;
		
		try {
			prtout = new PrintWriter(fileName);
			prtout.println(lineToPrint);
			prtout.flush();
			prtout.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public static void appendArray(ArrayList<Vehicle> v, String fileName) {
		PrintWriter prtout=null;
		try {
			prtout = new PrintWriter(fileName);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for(Vehicle newarr : v) {
			prtout.println(newarr);
		}
		prtout.flush();
		prtout.close();
		
	}
}

package vehicleActivity;

public class AirVehicle extends Vehicle{

	String maxAltitude;

	public AirVehicle(String color, String weight, String maxWeight, String minWeight, String fuelType, String maxAltitude ,String range) {
		super(color, weight, maxWeight, minWeight, fuelType, range);
		this.maxAltitude=maxAltitude;
		
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "AirVehicle [maxAltitude=" + maxAltitude +  ", range=" + range + ", color=" + color + ", weight=" + weight + ", maxWeight="
				+ maxWeight + ", minWeight=" + minWeight + ", fuelType=" + fuelType + "]";
	}

}

package vehicleActivity;

public class Car extends LandVehicle{

	String bodyType;

	public Car(String color, String weight, String maxWeight, String minWeight, String fuelType, String numWheels,
			String numDoors, String bodyType ,String range) {
		super(color, weight, maxWeight, minWeight, fuelType, numWheels, numDoors, range);
		this.bodyType=bodyType;
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Car [bodyType=" + bodyType + ", numWheels=" + numWheels +  ", range=" + range + ", numDoors=" + numDoors + ", color=" + color
				+ ", weight=" + weight + ", maxWeight=" + maxWeight + ", minWeight=" + minWeight + ", fuelType="
				+ fuelType + "]";
	}

}

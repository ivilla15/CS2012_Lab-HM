package vehicleActivity;

public class LandVehicle extends Vehicle{

	String numWheels;
	String numDoors;
	public LandVehicle(String color, String weight, String maxWeight, String minWeight, String fuelType, String numWheels, String numDoors ,String range) {
		super(color, weight, maxWeight, minWeight, fuelType, range);
		this.numWheels=numWheels;
		this.numDoors=numDoors;
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "LandVehicle [numWheels=" + numWheels + ", numDoors=" + numDoors +  ", range=" + range + ", color=" + color + ", weight="
				+ weight + ", maxWeight=" + maxWeight + ", minWeight=" + minWeight + ", fuelType=" + fuelType + "]";
	}

}

package vehicleActivity;

public class Truck extends LandVehicle{

	String cargoSize;
	String maxSize;
	String minSize;
	String cargoType;
	public Truck(String color, String weight, String maxWeight, String minWeight, String fuelType, String numWheels,
			String numDoors, String cargoSize, String maxSize, String minSize, String cargoType ,String range) {
		super(color, weight, maxWeight, minWeight, fuelType, numWheels, numDoors, range);
		this.cargoSize=cargoSize;
		this.maxSize=maxSize;
		this.minSize=minSize;
		this.cargoType=cargoType;
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Truck [cargoSize=" + cargoSize +  ", range=" + range + ", maxSize=" + maxSize + ", minSize=" + minSize + ", cargoType="
				+ cargoType + ", numWheels=" + numWheels + ", numDoors=" + numDoors + ", color=" + color + ", weight="
				+ weight + ", maxWeight=" + maxWeight + ", minWeight=" + minWeight + ", fuelType=" + fuelType + "]";
	}

}

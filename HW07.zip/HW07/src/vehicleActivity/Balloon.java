package vehicleActivity;

public class Balloon extends AirVehicle{

	String buoyantGas;

	public Balloon(String color, String weight, String maxWeight, String minWeight, String fuelType,
			String maxAltitude, String buoyantGas ,String range) {
		super(color, weight, maxWeight, minWeight, fuelType, maxAltitude, range);
		// TODO Auto-generated constructor stub
		this.buoyantGas=buoyantGas;
	}

	@Override
	public String toString() {
		return "Balloon [buoyantGas=" + buoyantGas +  ", range=" + range + ", maxAltitude=" + maxAltitude + ", color=" + color + ", weight="
				+ weight + ", maxWeight=" + maxWeight + ", minWeight=" + minWeight + ", fuelType=" + fuelType + "]";
	}

}

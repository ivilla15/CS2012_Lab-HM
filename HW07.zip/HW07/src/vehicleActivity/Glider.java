package vehicleActivity;

public class Glider extends AirVehicle{

	String wingSpan;

	public Glider(String color, String weight, String maxWeight, String minWeight, String fuelType,
			String maxAltitude, String wingSpan ,String range) {
		super(color, weight, maxWeight, minWeight, fuelType, maxAltitude, range);
		// TODO Auto-generated constructor stub
		this.wingSpan=wingSpan;
	}

	@Override
	public String toString() {
		return "Glider [wingSpan=" + wingSpan + ", maxAltitude=" + maxAltitude +  ", range=" + range +", color=" + color + ", weight="
				+ weight + ", maxWeight=" + maxWeight + ", minWeight=" + minWeight + ", fuelType=" + fuelType + "]";
	}

}

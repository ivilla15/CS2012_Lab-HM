package vehicleActivity;

public class Vehicle {
	String color;
	String weight;
	String maxWeight;
	String minWeight;
	String fuelType;
	String range;
	public Vehicle(String color, String weight, String maxWeight, String minWeight, String fuelType, String range) {
		super();
		this.color = color;
		this.weight = weight;
		this.maxWeight = maxWeight;
		this.minWeight = minWeight;
		this.fuelType = fuelType;
		this.range=range;
	}
	@Override
	public String toString() {
		return "Vehicle [color=" + color + ", weight=" + weight + ", maxWeight=" + maxWeight + ", minWeight="
				+ minWeight + ", fuelType=" + fuelType +  ", range=" + range + "]";
	}

}

package vehicleActivity;
import java.util.Random;
public class VehicleFactoryMain {
	public static void main(String[] args) {
	}
	public static Vehicle[] getNumArray() {
		Random ran = new Random(); 
		int numcars = ran.nextInt(4)+2;
		int numtrucks = ran.nextInt(4)+2;
		int numballons= ran.nextInt(4)+2;
		int numgliders= ran.nextInt(4)+2;
		String minrange="300.0Km";
		String maxrange="700.0Km";
		String maxheight="74334m";
		String minheight= "10000.0m";
		String maxweight="80000.0Kg";
		String minweight="20000.0Kg";
		String maxcargo="10.36m";
		String mincargo="5.55m";
		String maxwing="30.9m";
		String minwing="0.6m";
		String[] myarr= {"hot-air","hydrogen","helium","gas","electric","diesel","kerosene","methane","none"}; 
		String[] typetrucks= {"opened", "BoxTruck","van", "minivan", "dumpTruck"}; 
		String[] typeballon= {"hot-air", "helium", "hydrogen"}; 
		String[] typecar= {"sedan", "fastBack","coupe", "convertable", "hatchBack"}; 
		Vehicle[] vehicles=new Vehicle[numcars+numtrucks+numballons+numgliders];
		int total=0;
		int countofcars=0;
		int countoftrucks=0;
		int countofballons=0;
		int countofgliders=0;
		for (int count=0; count<5; count++) {
			if(countofcars<numcars) {
				System.out.println(total);
				int anewrand=ran.nextInt(1);
				int anewfuel=ran.nextInt(8);
				int anewbody=ran.nextInt(5);
				if(anewrand==0) {
					vehicles[total]=new Car("red", minweight, "2053Kg", "1003Kg", myarr[anewfuel], "4-wheels",
							"4-doors", typecar[anewbody] , maxrange);
					countofcars++;
					total++;
				}else {
					anewrand=ran.nextInt(1);
					anewfuel=ran.nextInt(8);
					anewbody=ran.nextInt(5);
					vehicles[total]=new Car("blue", maxweight, "2053Kg", "1003Kg", myarr[anewfuel], "4-wheels",
							"4-doors", typecar[anewbody] , minrange);
					countofcars++;
					total++;
				}
			}
			if(countoftrucks<numtrucks) {
					int anewrand=ran.nextInt(1);
					int anewfuel=ran.nextInt(8);
					int anewcargo=ran.nextInt(5);
					if(anewrand==0) {
						vehicles[total]=new Truck("orange", maxweight, maxweight, minweight, myarr[anewfuel], "10-wheels",
								"2-doors", maxcargo,"20m", "14m", typetrucks[anewcargo] , minrange);
						countoftrucks++;
						total++;
				}else {
					anewrand=ran.nextInt(1);
					anewfuel=ran.nextInt(8);
					anewcargo=ran.nextInt(5);
					vehicles[total]=new Truck("white", minweight, maxweight, minweight, myarr[anewfuel], "18-wheels",
							"2-doors", mincargo, "20m", "14m", typetrucks[anewcargo] , maxrange);
					countoftrucks++;
					total++;
				}
			}
			if(countofballons<numballons) {
				int anewrand=ran.nextInt(1);
				int anewfuel=ran.nextInt(8);
				int anewballon=ran.nextInt(3);
				if(anewrand==0) {
					vehicles[total]=new Balloon("green", maxweight, maxweight, minweight, myarr[anewfuel], 
							maxheight, typeballon[anewballon] , maxrange);
					countofballons++;
					total++;
				}else {
					anewrand=ran.nextInt(1);
					anewfuel=ran.nextInt(8);						
					anewballon=ran.nextInt(3);
					vehicles[total]=new Balloon("red", minweight, maxweight, minweight, myarr[anewfuel],
							minheight, typeballon[anewballon] , minrange);
					countofballons++;
					total++;
					}
			}
			if(countofgliders<numgliders) {
				int anewrand=ran.nextInt(1);
				int anewfuel=ran.nextInt(8);
				if(anewrand==0) {
					vehicles[total]=new Glider("yellow", maxweight, maxweight, minweight, myarr[anewfuel],
							maxheight, maxwing ,maxrange);
					countofgliders++;
					total++;
				}else {
					anewrand=ran.nextInt(1);
					anewfuel=ran.nextInt(8);
					vehicles[total]=new Glider("green", minweight, maxweight, minweight, myarr[anewfuel],
							minheight, minwing,minrange);
					countofgliders++;
					total++;
				}
			}
		}
		return vehicles;
    }
}
package university;

public class Faculty extends Employee{
String officehours;
String rank;
public Faculty(String name, String address, String phone, String email, String office, String salary, String datehired, String officehours, String rank) {
	super(name, address, phone, email, office, salary, datehired);
	// TODO Auto-generated constructor stub
	this.officehours=officehours;
	this.rank=rank;
}
public String getOfficehours() {
	return officehours;
}
public void setOfficehours(String officehours) {
	this.officehours = officehours;
}
public String getRank() {
	return rank;
}
public void setRank(String rank) {
	this.rank = rank;
}
@Override
public String toString() {
	return "Faculty [officehours=" + officehours + ", rank=" + rank + ", office=" + office + ", salary=" + salary
			+ ", datehired=" + datehired + ", name=" + name + ", address=" + address + ", phone=" + phone + ", email="
			+ email + "]";
}

}

package university;

public class Staff extends Employee{
String title;

public Staff(String name, String address, String phone, String email, String office, String salary, String datehired, String title) {
	super(name, address, phone, email, office, salary, datehired);
	// TODO Auto-generated constructor stub
	this.title=title;
}

public String getTitle() {
	return title;
}

public void setTitle(String title) {
	this.title = title;
}

@Override
public String toString() {
	return "Staff [title=" + title + ", office=" + office + ", salary=" + salary + ", datehired=" + datehired
			+ ", name=" + name + ", address=" + address + ", phone=" + phone + ", email=" + email + "]";
}

}

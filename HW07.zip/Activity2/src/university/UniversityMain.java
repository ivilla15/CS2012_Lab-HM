package university;

public class UniversityMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person man1= new Person("Issac", "444 Virginia Rd", "333444555", "issac@gmail.com");
		System.out.println(man1);
		Student man2= new Student("David", "222 Virginia Rd", "5556669999", "David@gmail.com", "Senior");
		System.out.println(man2);
		Employee man3= new Employee("Ben", "333 Virginia Rd", "1010102020", "ben@gmail.com", "Google", "$100,000", "02-03-2023");
		System.out.println(man3);
		Faculty man4= new Faculty("Alyssa", "444 Virginia Rd", "4449991010", "alyssa@gmail.com", "Google", "$100,000", "02-03-2023","Tuesday 3:00-4:00pm","Teacher");
		System.out.println(man4);
		Staff man5= new Staff("Emily", "333 Virginia Rd", "1010102020", "ben@gmail.com", "Google", "$100,000", "02-03-2023", "Janitor");
		System.out.println(man5);
	}

}

package university;

public class Employee extends Person{

String office;
String salary;
String datehired;
public Employee(String name, String address, String phone, String email,String office,String salary, String datehired) {
	super(name, address, phone, email);
	this.office=office;
	this.salary=salary;
	this.datehired=datehired;
	// TODO Auto-generated constructor stub
}
@Override
public String toString() {
	return "Employee [office=" + office + ", salary=" + salary + ", datehired=" + datehired + ", name=" + name
			+ ", address=" + address + ", phone=" + phone + ", email=" + email + "]";
}
public String getOffice() {
	return office;
}
public void setOffice(String office) {
	this.office = office;
}
public String getSalary() {
	return salary;
}
public void setSalary(String salary) {
	this.salary = salary;
}
public String getDatehired() {
	return datehired;
}
public void setDatehired(String datehired) {
	this.datehired = datehired;
}
}

package university;

public class Student extends Person{
String classstatus;

public Student(String name, String address, String phone, String email, String classstatus) {
	super(name, address, phone, email);
	this.classstatus=classstatus;
	// TODO Auto-generated constructor stub
}

public String getClassstatus() {
	return classstatus;
}

public void setClassstatus(String classstatus) {
	this.classstatus = classstatus;
}

@Override
public String toString() {
	return "Student [classstatus=" + classstatus + ", name=" + name + ", address=" + address + ", phone=" + phone
			+ ", email=" + email + "]";
}

}

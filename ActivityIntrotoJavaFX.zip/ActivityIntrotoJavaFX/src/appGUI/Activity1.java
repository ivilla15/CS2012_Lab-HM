package appGUI;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Activity1 extends Application {

	public static void main(String[] args) {
		Application.launch(args);
	}

    @Override
    public void start(Stage primaryStage) {
        try {
            Button b1=new Button("Button 1");
            Button b2= new Button("Button 2");
            
            HBox hb=new HBox();
            hb.setAlignment(Pos.CENTER);
            hb.getChildren().add(b1);
            hb.getChildren().add(b2);
            
            Label l1= new Label("Top text for the vbox.");
            Label l2= new Label("Bottom text for the vbox.");
            
            b1.setOnAction((event) -> { //lambda expression
            	l1.setText("Some random text after hitting button1.");
            });
            b2.setOnAction((event) -> { //lambda expression
            	l2.setText("Some random text after hitting button2.");
            });
            
            VBox root= new VBox();
            root.setAlignment(Pos.CENTER);
            root.getChildren().add(l1);
            root.getChildren().add(l2);
            root.getChildren().add(hb);
            
            Scene mainScene = new Scene(root,400,400);
            
            primaryStage.setScene(mainScene);
            primaryStage.show();
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}
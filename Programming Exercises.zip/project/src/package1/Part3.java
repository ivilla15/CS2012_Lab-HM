package package1;
import java.util.Scanner;
public class Part3 {
	public static void main(String[] args) {
	 System.out.println("Enter an integer");
	 Scanner sc = new Scanner(System.in);
	 int number;
	 do {
	     System.out.println("Please enter an integer!");
	     while (!sc.hasNextInt()) {
	         if(sc.hasNext("quit")) {
	        	 break;
	         }
	         System.out.println("That's not a integer!");
	         System.out.println("Please enter an integer!");
	         sc.next(); // this is important!
	     }
	     number = sc.nextInt();
	 } while (number <= 0);
	 System.out.println("Thank you! Got " + number);
	 
}
}

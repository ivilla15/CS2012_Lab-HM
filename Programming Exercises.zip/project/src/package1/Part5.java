package package1;

import java.io.File;
import java.io.PrintWriter;
import java.util.Scanner;

public class Part5 {
	public static void main(String[] args) {
		String pathString = "MyFile";
	try {
		File  file = new File(pathString);
		Scanner input= new Scanner(file);
		File  newfile = new File(pathString);
		Scanner newinput= new Scanner(newfile);
		
		int sum=0;
		while(input.hasNext()) {
			int score=Integer.parseInt(input.next());
			sum+=score;
        }
		int average=0;
		average=sum/15;
		PrintWriter prtout= new PrintWriter("Newmyfile");
		prtout.println(sum);
		prtout.println(average);
		int column=0;
		while(newinput.hasNext()) {
			prtout.print(Integer.parseInt(newinput.next())+" ");
			column++;
			if(column%4==0) {
				prtout.println();
			}
        }
		
		prtout.flush();
		prtout.close();
	} catch (Exception e) {// if something breaks catch and print out what went wrongSystem.err.println(e);
		System.out.println(e);
	}
	}
}
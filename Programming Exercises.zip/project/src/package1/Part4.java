package package1;
import java.util.Scanner;
public class Part4 {
	
	public static void main(String[] args) {
		System.out.println(squareFloat(getFloat()));
		
	}
	public static float getFloat() {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter an float: ");
		float newword = sc.nextFloat();
		return newword;
	}
	public static float squareFloat(float marks) {
		float newmarks=marks*marks;
		return newmarks;
	}
}

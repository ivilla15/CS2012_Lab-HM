package package1;
import java.util.Scanner;
public class Exercise2 {

	public static void main(String[] args) {
		 Scanner input = new Scanner(System.in);
	    	
	        System.out.print("Enter an string: ");
	        String word = input.next();
	        System.out.println("You entered " + word);
	        System.out.print("Enter an integer: ");
	        int number = input.nextInt();
	        System.out.println("You entered " + number);
	        System.out.print("Enter an string, integer, or float");
	        if (input.hasNextInt()) System.out.println("This input is of type Integer.");
	        else if (input.hasNextFloat()) System.out.println("This input is of type Float.");
	        else if (input.hasNextLine()) System.out.println("This input is of type string."); 
	        // closing the scanner object
	        input.close();
	}

}

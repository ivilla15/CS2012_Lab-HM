/**
 * 
 */
/**
 * @author isaiahvillalobos
 *
 */
module Money {
}
package Pack1;

public class Money implements Comparable<Money>, Calculable<Money>{
	private int dollars;
	private int cents;


	public Money(int dollars, int cents) {
		super();
		this.dollars = dollars;
		this.cents = cents;
	}

	public int getDollars() {
		return dollars;
	}

	public void setDollars(int dollars) {
		this.dollars = dollars;
	}

	public int getCents() {
		return cents;
	}

	public void setCents(int cents) {
		this.cents = cents;
	}

	@Override
	public Money add(Money o) {
		int countcent=cents+o.getCents();
		int countdol=dollars+o.getDollars();
		while(countcent>99) {
			countdol++;
			countcent-=100;
		}
		if(countdol>0&&countcent<0) {
		Money newmon=new Money((~(countdol - 1)), Math.abs(countcent));
		return newmon;
		}
		else {
		Money newmon=new Money(countdol, countcent);
		return newmon;
		}
	}

	@Override
	public Money subtract(Money o) {
		int countcent=cents-o.getCents();
		int countdol=dollars-o.getDollars();
		while(countcent<0) {
			countdol--;
			countcent+=100;
		}
		if(countdol>0&&countcent<0) {
			Money newmon=new Money((~(countdol - 1)), Math.abs(countcent));
			return newmon;
			}
			else {
			Money newmon=new Money(countdol, countcent);
			return newmon;
			}
	}

	@Override
	public int compareTo(Money o) {
		if(dollars>o.getDollars()) {
			return 1;
		}else if(dollars<o.getDollars()) {
			return -1;
		}else if(cents>o.getCents()) {
			return 1;
		}else if(cents<o.getCents()) {
			return -1;
		}else {
			return -1;
		}
	}

	@Override
	public String toString() {
		return "$" + dollars + "." + cents;
	}

}

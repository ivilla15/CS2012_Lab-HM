package Pack1;

public class Time implements Comparable<Time>, Calculable<Time>{

	private int hours;
	private int minutes;
	private int seconds;

	public Time(int hours, int minutes, int seconds) {
		super();
		this.hours = hours;
		this.minutes = minutes;
		this.seconds = seconds;
	}

	public int getHours() {
		return hours;
	}

	public void setHours(int hours) {
		this.hours = hours;
	}

	public int getMinutes() {
		return minutes;
	}

	public void setMinutes(int minutes) {
		this.minutes = minutes;
	}

	public int getSeconds() {
		return seconds;
	}

	public void setSeconds(int seconds) {
		this.seconds = seconds;
	}

	@Override
	public Time add(Time o) {
		int counthours=hours+o.getHours();
		int countmin=minutes+o.getMinutes();
		int countsec=seconds+o.getSeconds();
		while(countsec>59) {
			countmin++;
			countsec-=60;
		}
		while(countmin>59) {
			counthours++;
			countmin-=60;
		}if(counthours>23) {
			counthours-=23;
		}
		Time newtime=new Time(counthours, countmin, countsec);
		return newtime;
		}

	@Override
	public Time subtract(Time o) {
		int counthours=hours+o.getHours();
		int countmin=minutes+o.getMinutes();
		int countsec=seconds+o.getSeconds();
		while(countsec<0) {
			countmin--;
			countsec+=60;
		}
		while(countmin<0) {
			counthours--;
			countmin+=60;
		}if(counthours<0) {
			counthours+=23;
		}
		Time newtime=new Time(counthours, countmin, countsec);
		return newtime;
	}

	@Override
	public int compareTo(Time o) {
		if(hours>o.getHours()) {
			return 1;
		}else if(hours<o.getHours()) {
			return -1;
		}else if(minutes>o.getMinutes()) {
			return 1;
		}else if(minutes<o.getMinutes()) {
			return -1;
		}else if(seconds>o.getSeconds()) {
			return 1;
		}else if(seconds<o.getSeconds()) {
			return -1;
		}else {
			return -1;
		}
	}
	@Override
	public String toString() {
		return hours + ":" + minutes + ":" + seconds;
	}
}

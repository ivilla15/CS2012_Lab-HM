package Pack1;

import java.util.ArrayList;
import java.util.Collections;

public class Tester {

	public static void main(String[] args) {
		ArrayList<Money> allmon = new ArrayList<Money>();
		
		Money newmon=new Money(5000, 56);
		Money newmon2=new Money(3478, 99);
		Money newmon3=new Money(1475940, 19);
		Money newmon4=new Money(675849, 01);
		Money newmon5=new Money(84920, 76);
		allmon.add(newmon);
		allmon.add(newmon2);
		allmon.add(newmon3);
		allmon.add(newmon4);
		allmon.add(newmon5);
		
		ArrayList<Time> alltimes = new ArrayList<Time>();
		
		Time newtime=new Time(1, 0, 8);
		Time newtime2=new Time(21, 56, 59);
		Time newtime3=new Time(4, 29, 5);
		Time newtime4=new Time(11, 30, 32);
		Time newtime5=new Time(3, 30, 24);
		
		alltimes.add(newtime);
		alltimes.add(newtime2);
		alltimes.add(newtime3);
		alltimes.add(newtime4);
		alltimes.add(newtime5);
		
		Collections.shuffle(allmon);
		Collections.shuffle(alltimes);
		
		System.out.println("Adding");
		
		System.out.println();
		
		System.out.println(allmon.get(0).toString()+" + "+allmon.get(1).toString()+" = "+allmon.get(0).add(allmon.get(1)));
		System.out.println(allmon.get(1).toString()+" + "+allmon.get(2).toString()+" = "+allmon.get(1).add(allmon.get(2)));
		System.out.println(allmon.get(2).toString()+" + "+allmon.get(3).toString()+" = "+allmon.get(2).add(allmon.get(3)));
		System.out.println(allmon.get(3).toString()+" + "+allmon.get(4).toString()+" = "+allmon.get(3).add(allmon.get(4)));
		
		System.out.println();
		
		System.out.println("Subtracting");
		
		System.out.println();
		
		System.out.println(alltimes.get(0).toString()+" - "+alltimes.get(1).toString()+" = "+alltimes.get(0).add(alltimes.get(1)));
		System.out.println(alltimes.get(1).toString()+" - "+alltimes.get(2).toString()+" = "+alltimes.get(1).add(alltimes.get(2)));
		System.out.println(alltimes.get(2).toString()+" - "+alltimes.get(3).toString()+" = "+alltimes.get(2).add(alltimes.get(3)));
		System.out.println(alltimes.get(3).toString()+" - "+alltimes.get(4).toString()+" = "+alltimes.get(3).add(alltimes.get(4)));
		
		Collections.sort(allmon);
		Collections.sort(alltimes);
		
		System.out.println();
		System.out.println("Money sorted");
		System.out.println();
		
		for(Money moneys : allmon) {
			System.out.println(moneys.toString());
		}
		
		System.out.println();

		System.out.println("Time sorted");
		System.out.println();
		
		for(Time times : alltimes) {
			System.out.println(times.toString());
		}
	}
}


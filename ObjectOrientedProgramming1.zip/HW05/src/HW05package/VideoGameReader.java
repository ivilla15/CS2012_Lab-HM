package HW05package;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;


public class VideoGameReader {
	public static void main(String[] args) {
		String pathString = "vgsales.txt";
	try {
		File myObj = new File(pathString);
		Scanner newinput= new Scanner(myObj);
		VideoGame newArray[] = new VideoGame[3500]; 
		String line=newinput.next();
		int count=0;
		String videogamename;
		String platform;
		int year;
		String genre;
		String publisher;
		double salesNA;
		double salesJapan;
		double salesEU;
		double salesworld;
		String []myarray = null;
		line=newinput.nextLine();
		while(newinput.hasNext()){
			line=newinput.nextLine();
			int comma=line.indexOf(",");
			line=line.substring(comma+1);
			myarray=line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1);
			System.out.println(Arrays.toString(myarray));
			System.out.println(line);
			if(myarray[0].contains("\"")){
				myarray[0]=myarray[0]+myarray[1];
				VideoGame newvideogame=new VideoGame(myarray[0], myarray[2], Integer.parseInt(myarray[3]), myarray[4], myarray[5], Double.parseDouble(myarray[6]), Double.parseDouble(myarray[7]), Double.parseDouble(myarray[8]), Double.parseDouble(myarray[9]), Double.parseDouble(myarray[10]));
			}else {
			if(isInteger(myarray[2])){
				VideoGame newvideogame=new VideoGame(myarray[0], myarray[1], Integer.parseInt(myarray[2]), myarray[3], myarray[4], Double.parseDouble(myarray[5]), Double.parseDouble(myarray[6]), Double.parseDouble(myarray[7]), Double.parseDouble(myarray[8]), Double.parseDouble(myarray[9]));
			}else {
				VideoGame newvideogame=new VideoGame(myarray[0], myarray[1], 0, myarray[3], myarray[4], Double.parseDouble(myarray[5]), Double.parseDouble(myarray[6]), Double.parseDouble(myarray[7]), Double.parseDouble(myarray[8]), Double.parseDouble(myarray[9]));
		}
			}
		}
	}catch (Exception e) {// if something breaks catch and print out what went wrongSystem.err.println(e);
		System.out.println(e);
	}
}
	public static boolean isInteger(String str) {
	    if (str == null) {
	        return false;
	    }
	    int length = str.length();
	    if (length == 0) {
	        return false;
	    }
	    int i = 0;
	    if (str.charAt(0) == '-') {
	        if (length == 1) {
	            return false;
	        }
	        i = 1;
	    }
	    for (; i < length; i++) {
	        char c = str.charAt(i);
	        if (c < '0' || c > '9') {
	            return false;
	        }
	    }
	    return true;
	}
}

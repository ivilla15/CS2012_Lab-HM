package HW05package;

import java.util.Scanner;

public class VideoGameRunner {

	public static void main(String[] args) {
		System.out.println("Enter: 'genre' without '' to retrieve all videogames based on that genre.");
		System.out.println("Enter: 'platform' without '' to retrieve all videogames based on that platform.");
		System.out.println("Enter: 'publishers without '' to retrieve all videogames based on that publishers.");
		System.out.println("Enter: 'revenue without '' to retrieve all videogames based on their revenue.");
		Scanner input = new Scanner(System.in);
		String word = input.next();
		if(word=="genre"){
			
		}else if(word=="platform") {
			
		}else if(word=="publishers") {
			
		}else if(word=="revenue"){
			
		}
		}

}

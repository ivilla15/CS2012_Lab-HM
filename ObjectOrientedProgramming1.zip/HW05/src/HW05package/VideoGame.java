package HW05package;

public class VideoGame {
  private String videogamename;
  private String platform;
  private int year;
  private String genre;
  private String publisher;
  private double salesNA;
  private double salesJapan;
  private double salesEU;
  private double salesworld;
  private double othersales;
 VideoGame(String newvideogamename, String newPlatform, int newyear, String newgenre, String newpublisher, double newsalesna, double newsaleseu, double newsalesJapan, double newothersales, double newsalesworld){
	 newvideogamename=videogamename;
	 newPlatform= platform;
	 newyear=year;
	 newgenre=genre;
	 newpublisher=publisher;
	 newsalesna=salesNA;
	 newsalesJapan=salesJapan;
	 newsaleseu=salesEU;
	 newsalesworld=salesworld;
	 othersales=newothersales;
	 
}
public String getVideogamename() {
	return videogamename;
}
public void setVideogamename(String videogamename) {
	this.videogamename = videogamename;
}
public String getPlatform() {
	return platform;
}
public void setPlatform(String platform) {
	this.platform = platform;
}
public int getYear() {
	return year;
}
public void setYear(int year) {
	this.year = year;
}
public String getGenre() {
	return genre;
}
public void setGenre(String genre) {
	this.genre = genre;
}
public String getPublisher() {
	return publisher;
}
public void setPublisher(String publisher) {
	this.publisher = publisher;
}
public double getSalesNA() {
	return salesNA;
}
public void setSalesNA(double salesNA) {
	this.salesNA = salesNA;
}
public double getSalesJapan() {
	return salesJapan;
}
public void setSalesJapan(double salesJapan) {
	this.salesJapan = salesJapan;
}
public void setSalesOtherSales(double othersales) {
	this.othersales = othersales;
}
public double getSalesEU() {
	return salesEU;
}
public void setSalesEU(double salesEU) {
	this.salesEU = salesEU;
}
public double getSalesworld() {
	return salesworld;
}
public void setSalesworld(double salesworld) {
	this.salesworld = salesworld;
}
public void setOtherSales(double othersales) {
	this.othersales = othersales;
}
}
# ACM-WORDLE-Project

v 1.0
In src/wordle run javac *.java 
Then java StartWorlde to start program

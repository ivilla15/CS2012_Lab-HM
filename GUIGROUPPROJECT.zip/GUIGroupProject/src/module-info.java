module GUIGroupProject {
	requires javafx.controls;
	requires javafx.base;
	requires javafx.graphics;
	exports Gui;
}
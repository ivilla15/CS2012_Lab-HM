package Gui;

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.image.ImageView;

public class BusyBox extends Application {

	public static void main(String[] args) {
		Application.launch(args);
	}

    @Override
    public void start(Stage primaryStage) {
        try {
            Button b1=new Button("Button");
            CheckBox chkBold = new CheckBox("Red");
            CheckBox chk = new CheckBox("Yellow");
            RadioButton rad1 = new RadioButton("Red");
            RadioButton rad2 = new RadioButton("Yellow");
            
            ImageView img= new ImageView("right.png");
            img.setFitHeight(10);
            img.setFitWidth(10);
            Button btRight = new Button("Right", img);
            
            ImageView img2= new ImageView("01 Small.png");
            img2.setFitHeight(20);
            img2.setFitWidth(20);
            Button bt2 = new Button("Button", img2);
            
            ImageView labelimg1= new ImageView("graphic.png");
            labelimg1.setFitHeight(50);
            labelimg1.setFitWidth(100);

            ImageView labelimg2= new ImageView("iphone.gif");
            labelimg2.setFitHeight(100);
            labelimg2.setFitWidth(50);
            
            TextField tf = new TextField();
            tf.setMaxWidth(150);
            
            PasswordField pf = new PasswordField();
            tf.setMaxWidth(150);
            
            Label newlab= new Label("Enter a message: ");
            Label newpass= new Label("Enter a password: ");
            
            HBox newbox= new HBox();
            newbox.getChildren().add(newlab);
            newbox.getChildren().add(tf);
            
            HBox newboxpass= new HBox();
            newbox.getChildren().add(newpass);
            newbox.getChildren().add(pf);
            
            VBox hb=new VBox();
            hb.setAlignment(Pos.TOP_LEFT);
            hb.getChildren().add(b1);
            hb.getChildren().add(btRight);
            hb.getChildren().add(bt2);
            hb.getChildren().add(chkBold);
            hb.getChildren().add(chk);
            hb.getChildren().add(rad1);
            hb.getChildren().add(rad2);
            hb.getChildren().add(newbox);
            hb.getChildren().add(newboxpass);
            
            Label l1= new Label("Standard Widgets");
            Label l2= new Label("Graphic Label", labelimg1);
            Label l3= new Label("Image Label", labelimg2);

            TextArea taNote = new TextArea(); 
            taNote.setPrefColumnCount(20); 
            taNote.setPrefRowCount(5);
            taNote.setWrapText(true); taNote.setStyle("-fx-text-fill: red"); 
            taNote.setFont(Font.font("Times", 20));
            
            ScrollPane scrollPane = new ScrollPane(taNote);

            VBox root= new VBox();
            root.setAlignment(Pos.TOP_LEFT);
            root.getChildren().add(l1);
            root.getChildren().add(l2);
            root.getChildren().add(l3);
            root.getChildren().add(hb);
            root.getChildren().add(scrollPane);
            
            
            Scene mainScene = new Scene(root,400,400);
            
            primaryStage.setScene(mainScene);
            primaryStage.show();
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}

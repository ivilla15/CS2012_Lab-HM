package arraylistsEx;

public class Car {
	String make;
	String model;
	int year;
	String licenceplate;
	public Car(String make, String model, int year, String licenceplate) {
		super();
		this.make = make;
		this.model = model;
		this.year = year;
		this.licenceplate = licenceplate;
	}
	public String getMake() {
		return make;
	}
	public void setMake(String make) {
		this.make = make;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public String getLicenceplate() {
		return licenceplate;
	}
	public void setLicenceplate(String licenceplate) {
		this.licenceplate = licenceplate;
	}
	@Override
	public String toString() {
		return year+ " "+ make+" "+ model+" "+ licenceplate;
	}
}

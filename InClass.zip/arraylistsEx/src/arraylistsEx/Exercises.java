package arraylistsEx;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Exercises {

	public static void main(String[] args) {
		ArrayList<String> allStrings = new ArrayList<String>();
		allStrings.add("ask");
		allStrings.add("not");
		allStrings.add("what");
		allStrings.add("your");
		allStrings.add("county");
		allStrings.add("can");
		allStrings.add("do");
		allStrings.add("for");
		allStrings.add("you");
		allStrings.add("but");
		System.out.println(allStrings);
		System.out.println(sorting(allStrings));
	      
	String sentence=("How I want a drink alcoholic of course after the heavy lectures involving Quantum Mechanics");
	String[] sent= sentence.split(" ");
	ArrayList<String> list = new ArrayList<>(Arrays.asList(sent));
	System.out.println(list);
	System.out.println(sorting(list));
	
    
	}

	public static ArrayList<String> sorting(ArrayList<String> mylist){
		for(int i = 0; i<mylist.size(); i++) {
			for (int j = i+1; j<mylist.size(); j++) {
				if(mylist.get(i).compareTo(mylist.get(j))>0) {
					String temp = mylist.get(i);
					mylist.set(i, mylist.get(j));
					mylist.set(j, temp);
				}
			}
		}
		return mylist;
	}

}
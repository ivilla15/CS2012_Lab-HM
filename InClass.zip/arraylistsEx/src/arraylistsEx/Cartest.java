package arraylistsEx;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;


public class Cartest {

	public static void main(String[] args) {
		try {
			System.out.println("Enter file name");
			Scanner myObj = new Scanner(System.in);
			String userName = myObj.nextLine();  
			File amyObj = new File(userName);
			Scanner newinput= new Scanner(amyObj);
			ArrayList<Car> allCars = new ArrayList<Car>();
			while(newinput.hasNext()){
				String line=newinput.nextLine();
				String[] cars=line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1);
				allCars.add(new Car(cars[0], cars[1], Integer.parseInt(cars[2]), cars[3]));
			}
			for (int i = 0; i < allCars.size(); i++) {
	            for (int j = i + 1; j < allCars.size()-1; j++) {
	            	double a=allCars.get(i).getYear();
	            	double b=allCars.get(j).getYear();
	            	Car temp;
	                if (a<b) {
	                    // swapping
	                    temp = allCars.get(i);
	                    allCars.set(i ,allCars.get(i));
	                    allCars.set(j, temp);
	                }
	            }
	        }
			for(int a=0; a<allCars.size();a++) {
				System.out.println(allCars.get(a));
			}
			newinput.close();
			myObj.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

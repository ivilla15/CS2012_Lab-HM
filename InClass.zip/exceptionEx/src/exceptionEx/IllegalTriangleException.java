package exceptionEx;

public class IllegalTriangleException extends Exception {
private double perimeter;

 public IllegalTriangleException(double perimeter) {
   super( "The sum of any two sides is greater than the other side" +  perimeter);
   this.perimeter = perimeter;
}
 public double getPerimeter() {
   return perimeter;
}
public void setPerimeter(double perimeter) {
	this.perimeter = perimeter;
}
@Override
public String toString() {
	return "IllegalTriangleException [perimeter=" + perimeter + "]";
}
}
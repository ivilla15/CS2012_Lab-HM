package exceptionEx;

import java.util.Scanner;

public class Calculator {

	public static void main(String[] args) {
		System.out.println("Enter equation with spaces between");
		Scanner myObj = new Scanner(System.in);
		String equation=myObj.nextLine();
		String[] equ=null;
		equ=equation.split(" ");
		int num1=Integer.parseInt(equ[0]);
		String num2=equ[1];
		int num3=Integer.parseInt(equ[2]);
		int result=0;
		if(num2.equals("+")) {
			result=num1+num3;
			System.out.println(result);
		}else if(num2.equals("-")) {
			result=num1-num3;
			System.out.println(result);
		}else if(num2.equals("/")) {
			result=num1/num3;
			System.out.println(result);
		}else if (num2.equals("*")){
			result=num1*num3;
			System.out.println(result);
		}else {
			System.out.println("Wrong Input");
		}
		
		myObj.close();
	}

}

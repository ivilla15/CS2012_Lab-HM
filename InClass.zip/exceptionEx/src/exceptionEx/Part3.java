package exceptionEx;
import java.util.Random;
import java.util.Scanner;

public class Part3 {

	public static void main(String[] args) {
		int [] nums=new int[100];
		for(int a=0; a<nums.length;a++) {
			Random rand = new Random(); 
		    int int_random = rand.nextInt(101); 
		    nums[a]=int_random;
		}
		System.out.println("Enter index");
		Scanner myObj = new Scanner(System.in);
		String word=myObj.nextLine();
		int index=Integer.parseInt(word);
		if(index<100&&index>=0) {
		System.out.println(nums[index]);
		}else {
			System.out.println("Out of Bounds");
		}
		myObj.close();
	}
	

}

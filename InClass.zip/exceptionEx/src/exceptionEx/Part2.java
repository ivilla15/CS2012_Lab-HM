package exceptionEx;

import java.util.Scanner;

public class Part2 {

	public static void main(String[] args) {
	System.out.println(" 2  6");
	System.out.println("Enter their sum");
	Scanner myObj = new Scanner(System.in);
	String sum=myObj.nextLine();
	boolean iscorrect=false;
	while(iscorrect==false) {
	if (sum.equals("8")){
		System.out.println("Correct");
		iscorrect=true;
	}else {
		System.out.println("Read the numbers again");
	}
	sum=myObj.nextLine();
	}
	myObj.close();
	}
}

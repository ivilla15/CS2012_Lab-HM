module SnakeGame {
	requires javafx.graphics;
	requires javafx.base;
	requires javafx.controls;
	exports Main;
}
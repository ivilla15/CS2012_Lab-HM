package Main;

import java.util.Random;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class SnakeGame extends Application{
	
		// CONSTANTS
		private static final int GAMEWIDTH = 600;
		private static final int GAMEHEIGHT = 500;
		private static final int RADIUS = 5;
		
		private Pane root;
		
		private Text score;
		
		private Circle food;
		
		Random ran = new Random();
		
		private Snake snake;
		
		
		//Create snake add it to root
		private void newSnake() {
			
			this.snake = new Snake(GAMEWIDTH / 2, GAMEHEIGHT / 2, RADIUS);
			root.getChildren().add(this.snake);
			
		}
		
		//Create food add it to root
		public void newFood() {
			this.food = new Circle(ran.nextInt(GAMEWIDTH), ran.nextInt(GAMEHEIGHT), RADIUS);
			this.food.setFill(Color.RED);
			this.root.getChildren().add(this.food);
		}
		
		//Checks to see if the snake has touched the food
		public boolean hit() {
			return this.food.intersects(this.snake.getBoundsInLocal());
		}
		
		//Checks to see if the snake has collided with itself
		private boolean gameOver() {
			return this.snake.eatSelf();
		}
		
		//Primary function that see the movement of the snake occur
		//Check to see if snake has hit the food
		//Checks for gameOver();
		
		private void move() {
			Platform.runLater(() -> {
				// move the snake
				this.snake.step();
				adjustLocation();
				if(hit()) {
					this.snake.eat(this.food);
					this.score.setText("" + this.snake.getLength());
					newFood();
				} else if(gameOver()) {
					this.root.getChildren().clear(); //removes the components attached to the pane
					this.root.getChildren().add(this.score);
					this.score.setText("RESET" + this.snake.getLength());
					newSnake();
					newFood();
				}
			});
		}
		
		//Redirects the snake if it goes out of bounds
		private void adjustLocation() {
			if(this.snake.getCenterX() < 0) {
				this.snake.setCenterX(GAMEWIDTH);
			}else if(this.snake.getCenterX() >GAMEWIDTH) {
				this.snake.setCenterX(0);
			}
			
			if(this.snake.getCenterY() < 0) {
				this.snake.setCenterY(GAMEHEIGHT);
			}else if(this.snake.getCenterY() >GAMEHEIGHT) {
				this.snake.setCenterY(0);
			}
		}
		
		@Override
		public void start(Stage primaryStage) throws Exception {
			this.root = new Pane();
			this.root.setPrefSize(GAMEWIDTH, GAMEHEIGHT);
			
			this.score = new Text(0, 32, "0");
			this.root.getChildren().add(this.score);
			
			newFood();
			newSnake();
			
			//Thread
			Runnable r = () ->{
				try {
					for(;;) {
						move();
						Thread.sleep(150);
					}
				}catch(InterruptedException e) {
					
				}
			};
			
			Scene scene = new Scene(this.root);
			
			//Event Filter
			
			/**Event Filter is an EventHandler object 
			 * Event filter --> event is captured during the event capture stage
			 * Event Handler --> event is captured during the bubbling stage
			 * EVent filters ensures that an action occurs based on the event regardless of the actions of the children**/
			scene.addEventFilter(KeyEvent.KEY_PRESSED, event ->{
				KeyCode code = event.getCode();
				
				if(code == KeyCode.UP) {
					this.snake.setCurrDirection(Direction.UP);
				}else if(code == KeyCode.DOWN) {
					this.snake.setCurrDirection(Direction.DOWN);
				}else if(code == KeyCode.LEFT) {
					this.snake.setCurrDirection(Direction.LEFT);
				}else if(code == KeyCode.RIGHT) {
					this.snake.setCurrDirection(Direction.RIGHT);
				}
			});
			
			primaryStage.setTitle("Snake Game");
			primaryStage.setScene(scene);
			primaryStage.setResizable(false);
			primaryStage.show();
			
			Thread th = new Thread(r);
			th.setDaemon(true);
			th.start();
		}
		
	public static void main(String[] args) {
		Application.launch(args);
	}
}

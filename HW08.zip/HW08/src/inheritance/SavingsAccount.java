package inheritance;

public class SavingsAccount extends Account{
	private double interest;

	public SavingsAccount(int accnum, double interest) {
		super(accnum);
		this.interest=interest;
		// TODO Auto-generated constructor stub
	}

	@Override
	public void deposit(double sum) {
		// TODO Auto-generated method stub
		super.deposit(sum);
	}

	@Override
	public void withdraw(double sum) {
		// TODO Auto-generated method stub
		super.withdraw(sum);
	}

	@Override
	public double getBalance() {
		// TODO Auto-generated method stub
		return super.getBalance();
	}

	@Override
	public double getAccountNumber() {
		// TODO Auto-generated method stub
		return super.getAccountNumber();
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString()+" "+ "interest "+ interest;
	}

	public void addInterest(double interest) {
		this.interest += interest;
	}
	
}


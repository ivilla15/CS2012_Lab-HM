package inheritance;

public class TestPersons {

	public static void main(String[] args) {
		Person Bob= new Person("Bob");
		System.out.println(Bob.getName());
		Person David= new Person("David");
		David.setName("Bob");
		System.out.println(Bob.equals(David));
		System.out.println(Bob);
		Employee Marie= new Employee("Marie", 50000.0, 2022, "102948510");
		Marie.setAnnualsalary(60000);
		System.out.println(Marie.getAnnualsalary());
		Marie.setStartyear(2021);
		System.out.println(Marie.getStartyear());
		Marie.setInsurancenum("102948511");
		System.out.println(Marie.getInsurancenum());
		System.out.println(Marie);
		System.out.println(Marie.equals(David));
	}

}

package inheritance;

public class Employee extends Person{
	private double annualsalary;
	private int startyear;
	private String insurancenum;
	public Employee() {
		super();
		annualsalary=0;
		startyear=0;
		insurancenum="";
		// TODO Auto-generated constructor stub
	}
	public Employee(String n, double annualsalary, int startyear, String insurancenum) {
		super(n);
		this.annualsalary=annualsalary;
		this.startyear=startyear;
		this.insurancenum=insurancenum;
		// TODO Auto-generated constructor stub
	}
	public double getAnnualsalary() {
		return annualsalary;
	}
	public void setAnnualsalary(double annualsalary) {
		this.annualsalary = annualsalary;
	}
	public int getStartyear() {
		return startyear;
	}
	public void setStartyear(int startyear) {
		this.startyear = startyear;
	}
	public String getInsurancenum() {
		return insurancenum;
	}
	@Override
	public String toString() {
		return "Employee [annualsalary=" + annualsalary + ", startyear=" + startyear + ", insurancenum=" + insurancenum+ ", name="+super.getName()
				+ "]";
	}
	public void setInsurancenum(String insurancenum) {
		this.insurancenum = insurancenum;
	}
	public boolean equals(Person p)
	{
		return super.getName().equals(p.getName());
	}
}




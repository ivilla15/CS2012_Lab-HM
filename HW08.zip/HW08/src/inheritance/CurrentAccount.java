package inheritance;

public class CurrentAccount extends Account{
private double overdraft;

public CurrentAccount(int accnum, double overdraft) {
	super(accnum);
	this.overdraft=overdraft;
	// TODO Auto-generated constructor stub
}

@Override
public void deposit(double sum) {
	// TODO Auto-generated method stub
	super.deposit(sum);
}

@Override
public void withdraw(double sum) {
	// TODO Auto-generated method stub
	super.withdraw(sum);
}

@Override
public double getBalance() {
	// TODO Auto-generated method stub
	return super.getBalance();
}

@Override
public double getAccountNumber() {
	// TODO Auto-generated method stub
	return super.getAccountNumber();
}

@Override
public String toString() {
	// TODO Auto-generated method stub
	return super.toString()+" "+"overdraft "+overdraft;
}

public double getOverdraft() {
	return overdraft;
}

public void setOverdraft(double overdraft) {
	this.overdraft = overdraft;
}
}

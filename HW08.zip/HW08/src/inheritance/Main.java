package inheritance;

public class Main {

	public static void main(String[] args) {
		Account myacc= new Account(1);
		myacc.deposit(150.0);
		myacc.withdraw(50.0);
		myacc.getBalance();
		myacc.getAccountNumber();
		myacc.toString();
		SavingsAccount mysave= new SavingsAccount(2, 0.25);
		CurrentAccount mycurr= new CurrentAccount(3, 0);
		mycurr.deposit(1000);
		mycurr.withdraw(2000);
		mysave.deposit(5000);
		mysave.withdraw(2000);
		mycurr.setOverdraft(1000);
		Bank Chase= new Bank(myacc);
		Chase.openaccount();
		Chase.closeaccount(4);
		Chase.paydividend();
		Chase.update(mycurr);
		System.out.println(myacc);
		System.out.println(mysave);
		System.out.println(mycurr);
	}

}

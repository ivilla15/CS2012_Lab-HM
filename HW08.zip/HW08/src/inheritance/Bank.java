package inheritance;

import java.util.ArrayList;

public class Bank {
	
private ArrayList<Account> accounts=new ArrayList<>();

	public Bank(Account myacc) {
		accounts.add(myacc);
	}
	public Bank(SavingsAccount myacc) {
		accounts.add(myacc);
		update(myacc);
		}
	public Bank(CurrentAccount myacc) {
		accounts.add(myacc);
		update(myacc);
		}
	public void update(SavingsAccount myacc) {
		myacc.addInterest(0.5);
	}
	public void update(CurrentAccount myacc) {
		double overdraft=myacc.getOverdraft();
		if(overdraft>500.0) {
			System.out.println("Dear Sir/Madam\n"
					+ "This letter sets out important information relating to one or more of your accounts with us.\n"
					+ "Recently your account has been overdrawn.\n"
					+ "Please arrange for the credits necessary to clear this palance to be paid in as soon as possible.\n"
					+ "Overdrafts are allowed to customers only by previous arrangents. \n"
					+ "Should you have any questions or concerns please feel free to contact me on 08 8407 6181.\n"
					+ "Bank");
		}
	}
	public void openaccount() {
		Account newacc= new Account(accounts.size());
		accounts.add(newacc);
	}
	public void closeaccount(int accnum) {
		for(int a=0; a<accounts.size();a++) {
			double accnum1=accounts.get(a).getAccountNumber();
			if(accnum==accnum1) {
				accounts.remove(a);
			}
		}
	}
	public void paydividend() {
		for(int a=0; a<accounts.size();a++) {
			double total=accounts.get(a).getBalance();
			accounts.get(a).deposit(total*0.02);
		}
	}
	
}

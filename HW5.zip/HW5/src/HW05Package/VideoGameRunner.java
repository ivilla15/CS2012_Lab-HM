package HW05Package;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;
public class VideoGameRunner {

		public static void main(String[] args) {
			try {
			String pathString = "vgsales.txt";
			File myObj = new File(pathString);
			Scanner newinput= new Scanner(myObj);
			VideoGame []videogames=new VideoGame[3500];
			String line=newinput.next();
			String []myarray = null;
			line=newinput.nextLine();
			int count=0;
			while(newinput.hasNext()){
				line=newinput.nextLine();
				int comma=line.indexOf(",");
				line=line.substring(comma+1);
				myarray=line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1);
				if(myarray[2].equals("N/A")) {
					videogames[count]=new VideoGame(myarray[0], myarray[1], 0, myarray[3], myarray[4], Double.parseDouble(myarray[5]), Double.parseDouble(myarray[6]), Double.parseDouble(myarray[7]), Double.parseDouble(myarray[8]), Double.parseDouble(myarray[9]));
					count++;
				}else {
				videogames[count]=new VideoGame(myarray[0], myarray[1], Integer.parseInt(myarray[2]), myarray[3], myarray[4], Double.parseDouble(myarray[5]), Double.parseDouble(myarray[6]), Double.parseDouble(myarray[7]), Double.parseDouble(myarray[8]), Double.parseDouble(myarray[9]));
				count++;
				}
			}
			for (int i = 0; i < videogames.length; i++) {
	            for (int j = i + 1; j < videogames.length-1; j++) {
	            	double a=videogames[i].getSalesworld();
	            	double b=videogames[j].getSalesworld();
	            	VideoGame temp=new VideoGame();
	                if (a<b) {
	                    // swapping
	                    temp = videogames[i];
	                    videogames[i] = videogames[j];
	                    videogames[j] = temp;
	                }
	            }
	        }
			boolean iscontinue=true;
			while (iscontinue) {
			System.out.println("Enter: 1 to retrieve all videogames based on that genre.");
			System.out.println("Enter: 2 to retrieve all videogames based on that platform.");
			System.out.println("Enter: 3 to retrieve all videogames based on that publishers.");
			System.out.println("Enter: 4 to retrieve all videogames based on their revenue.");
			System.out.println("Enter: 5 to quit");
			Scanner input = new Scanner(System.in);
			int word = input.nextInt();
			switch(word){
			case 1:System.out.println("Enter a genre");
			String genre=input.next();
			System.out.println("- Collect games by genre -->"+getByGenre(genre,videogames));
			break;
			case 2:System.out.println("Enter a platform");
			String platform=input.next();
			System.out.println("- Collect games by platform -->"+getByPlatform(platform,videogames));
			break;
			case 3:
				System.out.println("Enter a publisher");
				String publishers=input.next();
				System.out.println("- Collect games by Publishers -->"+getByPublishers(publishers,videogames));
			break;	
			case 4:
				System.out.println("Enter a value");
				int value=input.nextInt();
				System.out.println("Enter 'less' or more'");
				String operation=input.next();
				System.out.println("- Collected games based on total revenue made -->" +getByRevenue(value,operation, videogames));
			break;
			case 5:
				iscontinue=false;
				break;
			default:
				System.out.println("Not Successful");
				break;
			}
			}
		}catch (Exception e) {// if something breaks catch and print out what went wrongSystem.err.println(e);
			System.out.println(e);
		}
		}
		public static boolean isInteger(String str) {
		    if (str == null) {
		        return false;
		    }
		    int length = str.length();
		    if (length == 0) {
		        return false;
		    }
		    int i = 0;
		    if (str.charAt(0) == '-') {
		        if (length == 1) {
		            return false;
		        }
		        i = 1;
		    }
		    for (; i < length; i++) {
		        char c = str.charAt(i);
		        if (c < '0' || c > '9') {
		            return false;
		        }
		    }
		    return true;
		}
		public static int getByGenre(String genre, VideoGame[] array) {
			int count=0;
			String pathString = genre+".txt";
			File file = new File(pathString);
			PrintWriter prtout;
			try {
				prtout = new PrintWriter(file);
			genre=genre.toLowerCase();
			for (int i = 0; i < array.length-1; i++) {
				if(array[i].getGenre().toLowerCase().equals(genre)) {
					count++;
					prtout.print(array[i].getVideogamename()+", "+array[i].getPlatform()+", "+array[i].getYear()+", "+array[i].getGenre()+", "+array[i].getPublisher()+", "+array[i].getSalesNA()+", "+array[i].getSalesEU()+", "+array[i].getSalesJapan()+", "+array[i].getOtherSales()+", "+array[i].getSalesworld());
					prtout.flush();
					prtout.close();
				}
			}
			}catch (Exception e) {// if something breaks catch and print out what went wrongSystem.err.println(e);
				System.out.println(e);
					}
			return count;
		}
		public static int getByPlatform(String platform, VideoGame[] array) {
			int count=0;
			String pathString = platform+".txt";
			File file = new File(pathString);
			PrintWriter prtout;
			try {
				prtout = new PrintWriter(file);
				platform=platform.toLowerCase();
				for (int i = 0; i < array.length-1; i++) {
					if(array[i].getPlatform().toLowerCase().equals(platform)) {
						count++;
						prtout.print(array[i].getVideogamename()+", "+array[i].getPlatform()+", "+array[i].getYear()+", "+array[i].getGenre()+", "+array[i].getPublisher()+", "+array[i].getSalesNA()+", "+array[i].getSalesEU()+", "+array[i].getSalesJapan()+", "+array[i].getOtherSales()+", "+array[i].getSalesworld());
						prtout.flush();
						prtout.close();
					}
				}
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return count;
		}
		public static int getByPublishers(String publisher, VideoGame[] array) {
			int count=0;
			String pathString = publisher+".txt";
			File file = new File(pathString);
			PrintWriter prtout;
			publisher=publisher.toLowerCase();
			try {
				prtout = new PrintWriter(file);
				for (int i = 0; i < array.length-1; i++) {
					if(array[i].getPublisher().toLowerCase().equals(publisher)) {
						count++;
						prtout.print(array[i].getVideogamename()+", "+array[i].getPlatform()+", "+array[i].getYear()+", "+array[i].getGenre()+", "+array[i].getPublisher()+", "+array[i].getSalesNA()+", "+array[i].getSalesEU()+", "+array[i].getSalesJapan()+", "+array[i].getOtherSales()+", "+array[i].getSalesworld());
						prtout.flush();
						prtout.close();
					}
				}
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return count;
		}
		public static int getByRevenue(int revenue,String operator, VideoGame[] array) {
			int count=0;
			operator=operator.toLowerCase();
			String pathString = revenue+".txt";
			File file = new File(pathString);
			PrintWriter prtout;
			try {
				prtout = new PrintWriter(file);
				if(operator.equals("less")) {
					for (int i = 0; i < array.length-1; i++) {
						if(array[i].getSalesworld()<revenue) {
							count++;
							prtout.print(array[i].getVideogamename()+", "+array[i].getPlatform()+", "+array[i].getYear()+", "+array[i].getGenre()+", "+array[i].getPublisher()+", "+array[i].getSalesNA()+", "+array[i].getSalesEU()+", "+array[i].getSalesJapan()+", "+array[i].getOtherSales()+", "+array[i].getSalesworld());
							prtout.flush();
							prtout.close();
						}
					}
				}else {
					for (int i = 0; i < array.length-1; i++) {
						if(array[i].getSalesworld()>revenue) {
							count++;
							prtout.print(array[i].getVideogamename()+", "+array[i].getPlatform()+", "+array[i].getYear()+", "+array[i].getGenre()+", "+array[i].getPublisher()+", "+array[i].getSalesNA()+", "+array[i].getSalesEU()+", "+array[i].getSalesJapan()+", "+array[i].getOtherSales()+", "+array[i].getSalesworld());
							prtout.flush();
							prtout.close();
						}
					}
				}
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return count;
		}
	}


/**
 * 
 */
/**
 * @author isaiahvillalobos
 *
 */
module HM05Copy {
}
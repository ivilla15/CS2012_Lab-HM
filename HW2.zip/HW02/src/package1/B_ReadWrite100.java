package package1;
import java.io.File;
import java.io.PrintWriter;
import java.util.Scanner;
public class B_ReadWrite100 {
		public static void main(String[] args) {
			String pathString = "numbersColumn.txt";
			String apathString = "numberRow.txt";
			try {
				File file = new File(pathString);
				File myObj = new File(apathString);
				Scanner newinput= new Scanner(myObj);
				PrintWriter prtout= new PrintWriter(file);
				while(newinput.hasNext()){
					prtout.print(Integer.parseInt(newinput.next())+" ");
		        }
				prtout.flush();
				prtout.close();
			}catch (Exception e) {// if something breaks catch and print out what went wrongSystem.err.println(e);
				System.out.println(e);
			}
		}
}


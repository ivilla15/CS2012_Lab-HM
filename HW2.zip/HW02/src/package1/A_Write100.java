package package1;
import java.io.File;
import java.io.PrintWriter;
import java.util.Random;
public class A_Write100 {
	public static void main(String[] args) {
		String pathString = "numberRow.txt";
		try {
			File myObj = new File(pathString);
			PrintWriter prtout= new PrintWriter("numberRow.txt");
			for(int num=0; num<100; num++) {
				int randomint=(int)(Math.random()*(101));
				prtout.print(randomint+" ");
			}
			prtout.flush();
			prtout.close();
		}catch (Exception e) {// if something breaks catch and print out what went wrongSystem.err.println(e);
			System.out.println(e);
		}
	}
	}

package package1;
import java.io.File;
import java.io.PrintWriter;
import java.util.Scanner;
public class F_SortName {
		public static void main(String[] args) {
			String pathString = "namesList.txt";
			String apathString = "randomPeople.txt";
			try {
				File file = new File(pathString);
				File myObj = new File(apathString);
				Scanner newinput= new Scanner(myObj);
				PrintWriter prtout= new PrintWriter(file);
				String firstnames[];
				firstnames = new String[100];
				String lastnames[];
				lastnames = new String[100];
				int count=0;
				String temp;
				while(newinput.hasNext()){
					firstnames[count]=newinput.next();
					lastnames[count]=newinput.next();
					count++;
		        }
				int n=100;
		        for (int i = 0; i < n; i++) {
		            for (int j = i + 1; j < n; j++) {
		                if (lastnames[i].compareTo(lastnames[j]) > 0) {
		                    // swapping
		                    temp = lastnames[i];
		                    lastnames[i] = lastnames[j];
		                    lastnames[j] = temp;
		                }
		            }
		        }
		        for (int i = 0; i < n; i++) {
		            prtout.println(lastnames[i]);
		        }
				prtout.flush();
				prtout.close();
			}catch (Exception e) {// if something breaks catch and print out what went wrongSystem.err.println(e);
				System.out.println(e);
			}
		}
}


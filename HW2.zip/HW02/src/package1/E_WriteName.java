package package1;
import java.io.File;
import java.io.PrintWriter;
import java.util.Scanner;
public class E_WriteName {
		public static void main(String[] args) {
			String pathString = "randomPeople.txt";
			String apathString = "firstNames.txt";
			String apathString2 = "lastNames.txt";
			try {
				File file = new File(pathString);
				File myObj = new File(apathString);
				File myObj2 = new File(apathString2);
				Scanner newinput= new Scanner(myObj);
				Scanner input= new Scanner(myObj2);
				PrintWriter prtout= new PrintWriter(file);
				while(newinput.hasNext()){
					prtout.println(newinput.next()+", "+input.next());
		        }
				prtout.flush();
				prtout.close();
			}catch (Exception e) {// if something breaks catch and print out what went wrongSystem.err.println(e);
				System.out.println(e);
			}
		}
}


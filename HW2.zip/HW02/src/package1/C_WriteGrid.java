package package1;
import java.io.File;
import java.io.PrintWriter;
import java.util.Random;
public class C_WriteGrid {

	public static void main(String[] args) {
				String pathString = "numberGrid.txt";
				try {
					File myObj = new File(pathString);
					PrintWriter prtout= new PrintWriter("numberGrid.txt");
					for(int row=0; row<10; row++) {
						for(int col=0; col<10; col++) {
							int randomint=(int)(Math.random()*(21));
							prtout.print(randomint+" ");
						}
						prtout.println();
					}
					prtout.flush();
					prtout.close();
				}catch (Exception e) {// if something breaks catch and print out what went wrongSystem.err.println(e);
					System.out.println(e);
				}


	}

}

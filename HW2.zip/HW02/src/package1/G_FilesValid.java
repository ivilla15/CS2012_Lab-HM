package package1;

import java.io.File;

public class G_FilesValid {

	public static void main(String[] args) {
		File aFile = new File("numberRow.txt");
		File aFile1 = new File("numbersColumn.txt");
		File aFile2 = new File("numberGrid.txt");
		File aFile3 = new File("gridStats.txt");
		File aFile4 = new File("randomPeople.txt");
		File aFile5 = new File("namesList.txt");
		
		if(!aFile.exists()){
			System.out.println("Missing numberRow.txt");
		}
		if(!aFile1.exists()){
			System.out.println("Missing numbersColumn.txt");
		}
		if(!aFile2.exists()){
			System.out.println("Missing numberGrid.txt");
		}
		if(!aFile3.exists()){
			System.out.println("Missing gridStats.txt");
		}
		if(!aFile4.exists()){
			System.out.println("Missing randomPeople.txt");
		}
		if(!aFile5.exists()){
			System.out.println("Missing namesList.txt");
		}
		System.out.println("all complete");
	}

}

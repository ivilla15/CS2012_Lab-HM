package package1;
import java.io.File;
import java.io.PrintWriter;
import java.util.Scanner;
public class D_WriteStats {
		public static void main(String[] args) {
			String pathString = "gridStats.txt";
			String apathString = "numberGrid.txt";
			try {
				File file = new File(pathString);
				File myObj = new File(apathString);
				Scanner newinput= new Scanner(myObj);
				PrintWriter prtout= new PrintWriter(file);
				int grandtotal=0;
				int rowtotal[];
				rowtotal = new int[10];
				int coltotal[];
				coltotal = new int[10];
				int num=0;
				int num17=0;
				for(int row=0; row<10; row++) {
					for(int col=0; col<10; col++) {
					num=Integer.parseInt(newinput.next());
					rowtotal[row]+=num;
					rowtotal[col]+=num;
					grandtotal+=num;
					if(num==17) {
						num17++;
					}
					}
		        }
				int average=grandtotal/100;
				prtout.println("Grand Total="+grandtotal);
				prtout.println("Average="+average);
				prtout.println("Row 1 Total="+rowtotal[0]);
				prtout.println("Row 2 Total="+rowtotal[1]);
				prtout.println("Row 3 Total="+rowtotal[2]);
				prtout.println("Row 4 Total="+rowtotal[3]);
				prtout.println("Row 5 Total="+rowtotal[4]);
				prtout.println("Row 6 Total="+rowtotal[5]);
				prtout.println("Row 7 Total="+rowtotal[6]);
				prtout.println("Row 8 Total="+rowtotal[7]);
				prtout.println("Row 9 Total="+rowtotal[8]);
				prtout.println("Row 10 Total="+rowtotal[9]);
				prtout.println("Column 1 Total="+coltotal[0]);
				prtout.println("Column 2 Total="+coltotal[1]);
				prtout.println("Column 3 Total="+coltotal[2]);
				prtout.println("Column 4 Total="+coltotal[3]);
				prtout.println("Column 5 Total="+coltotal[4]);
				prtout.println("Column 6 Total="+coltotal[5]);
				prtout.println("Column 7 Total="+coltotal[6]);
				prtout.println("Column 8 Total="+coltotal[7]);
				prtout.println("Column 9 Total="+coltotal[8]);
				prtout.println("Column 10 Total="+coltotal[9]);
				prtout.println("Number of 17s="+num17);
				prtout.flush();
				prtout.close();
			}catch (Exception e) {// if something breaks catch and print out what went wrongSystem.err.println(e);
				System.out.println(e);
			}
		}
}


package package1;
import java.io.File;
import java.io.PrintWriter;
import java.util.Scanner;
public class H_ReadFile {
		public static void main(String[] args) {
			String apathString = "jabberwocky.txt";
			String apathString2 = "mindkiller.txt";
			try {
				File myObj = new File(apathString);
				File myObj2 = new File(apathString2);
				Scanner newinput= new Scanner(myObj);
				Scanner input= new Scanner(myObj2);
				int charCount = 0;
				
				int wordCount = 0;
				
				int lineCount = 0;
				
				int charCount1 = 0;
				
				int wordCount1 = 0;
				
				int lineCount1 = 0;
				while(newinput.hasNextLine()){
					      lineCount++;
					      String line = newinput.nextLine();
					      Scanner lineScanner = new Scanner(line);
					      // count the characters of the file till the end
					      while(lineScanner.hasNext()) {
					        wordCount++;
					        String word = lineScanner.next();
					        charCount += word.length();
					      } 

					    lineScanner.close();
					  }
				while(input.hasNextLine()){
					      lineCount1++;
					      String line = input.nextLine();
					      Scanner lineScanner = new Scanner(line);
					      // count the characters of the file till the end
					      while(lineScanner.hasNext()) {
					        wordCount1++;
					        String word = lineScanner.next();
					        charCount1 += word.length();
					      } 

					    lineScanner.close();
					  }

					  //display the count of characters, words, and lines
					  System.out.println("# of chars in jabberwocky.txt: " + charCount);
					  System.out.println("# of words in jabberwocky.txt: " + wordCount);
					  System.out.println("# of lines in jabberwocky.txt: " + lineCount);
					  System.out.println("# of chars in mindkiller.txt: " + charCount1);
					  System.out.println("# of words in mindkiller.txt: " + wordCount1);
					  System.out.println("# of lines in mindkiller.txt: " + lineCount1);
			}catch (Exception e) {// if something breaks catch and print out what went wrongSystem.err.println(e);
				System.out.println(e);
			}
		}
}


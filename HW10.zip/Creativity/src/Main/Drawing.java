package Main;

import java.util.Random;

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
//import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Arc;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Ellipse;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.image.ImageView;

public class Drawing extends Application {

	public static void main(String[] args) {
		Application.launch(args);
	}

    @Override
    public void start(Stage primaryStage) {
        try {
        	Rectangle r1= new Rectangle(1250,800);
        	
        	Circle center = new Circle(100,100,100);
        	Circle ball = getCircle(getNum());
        	Circle ball2 = getCircle(getNum());
        	Circle ball3 = getCircle(getNum());
        	Circle ball4 = getCircle(getNum());
        	
        	Ellipse rings = new Ellipse(25,25,25,50); 
        	
        	Arc arc= new Arc(50,50,50,50,130,100);
        	  
        	Polygon polygon = getStar(getNum());
        	Polygon polygon1 = getStar(getNum());
        	Polygon polygon2 = getStar(getNum());
        	Polygon polygon3 = getStar(getNum());
        	Polygon polygon4 = getStar(getNum());

        	
        	r1.setFill(Color.BLACK);
            r1.setStroke(Color.WHITE);
            
        	center.setFill(Color.ORANGE);
        	center.setStroke(Color.WHITE);
        	
        	
        	ball.setFill(getColor());
        	ball2.setFill(Color.AQUA);
        	ball3.setFill(Color.LIGHTCORAL);
        	ball4.setFill(getColor());
        	
        	
        	arc.setFill(Color.LIGHTGOLDENRODYELLOW);
        	
        	rings.setFill(Color.DEEPPINK);
        	
        	polygon.setFill(getColor());
        	polygon1.setFill(getColor());
        	polygon2.setFill(getColor());
        	polygon3.setFill(getColor());
        	polygon4.setFill(getColor());
        	
        	StackPane root= new StackPane();
        	
        	GridPane lay = new GridPane();
        	
        	lay.setHgap(10);
            lay.setVgap(10);
            lay.setPadding(new Insets(0, 150, 75, 0));
        	lay.add(center, 0, 3);
        	lay.add(arc, 73, 10);
        	lay.add(rings, 75, 10);
        	lay.add(polygon, 100, 35);
        	lay.add(polygon2, 20, 15);
        	lay.add(polygon3, 35, 25);
        	lay.add(polygon4, 80, 45);
        	lay.add(ball4, 90, 15);
        	lay.add(ball3, 60, 45);
        	lay.add(ball2, 35, 45);
        	lay.add(ball, 50, 50);
        	
            root.setAlignment(Pos.CENTER);
            root.setPadding(new Insets(10,10,10,10));
            root.getChildren().add(r1);
            root.getChildren().add(center);
            root.getChildren().add(lay);
            
            primaryStage.setTitle("Space");
        	
            Scene mainScene = new Scene(root,500,500);
            mainScene.setFill(getColor());
            
            primaryStage.setScene(mainScene);
            primaryStage.show();
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
    
    Color getColor() {
    	Random rand = new Random();
    	float r = rand.nextFloat();
    	float g = rand.nextFloat();
    	float b = rand.nextFloat();
    	Color randomColor = new Color(r, g, b,1);
    	return randomColor;
    }
    
    double getNum() {
    	Random rand = new Random();
    	double num = rand.nextDouble()*1.5+1;
    	return num;
    }
    
    Polygon getStar(double num) {
    	double points[] = {  10.0*num, 15.0*num,
                15.0*num, 30.0*num,
                35.0*num, 30.0*num,
                40.0*num, 15.0*num,
                25.0*num, 5.0*num};
    	  
    	        // create a polygon
    	        Polygon polygon = new Polygon(points);
    	        return polygon;
    }
    
    Circle getCircle(double num) {
    	Circle ball = new Circle(10*num,10*num,10*num);
    	return ball;
    }
}

package Main;

import java.io.File;
import java.util.Random;
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.image.ImageView;

public class RanCards extends Application {

	public static void main(String[] args) {
		Application.launch(args);
	}
	@Override
	public void start(Stage primaryStage){
			int num=(int)(Math.random()*53);
			GridPane pane= new GridPane();
			pane.setAlignment(Pos.CENTER);
			pane.setPadding(new Insets(10,10,10,10));
			pane.setHgap(15);
			pane.setVgap(15);
			int col=0;
			int row=0;
			for(int i=0; i<7; i++) {
				ImageView img=new ImageView(new Image(new File("cards/" + Integer.toString(num)+".png").toURI().toString()));
				img.setFitWidth(200);
				img.setFitHeight(300);
				pane.add(img, col, row);
				if(col==4) {
					col=0;
					row++;
				}else {
					col++;
				}
				
			num=(int)(Math.random()*53);
			}
			Pane newpane = new Pane(pane);
			Scene mainScene = new Scene(newpane,500,500);
            primaryStage.setScene(mainScene);
            primaryStage.show();
		
	}
}

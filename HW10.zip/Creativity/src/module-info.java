/**
 * 
 */
/**
 * @author isaiahvillalobos
 *
 */
module Creativity {
		requires javafx.controls;
		requires javafx.base;
		requires javafx.graphics;
		exports Main;
}